<?php $__env->startSection('content'); ?>
<style>
    .elementor-2124 .elementor-element.elementor-element-1be14109 .elementskit-section-title-wraper .elementskit-section-title {
        color: #14223B;
        margin: 0px 0px 16px 0px;
        font-family: "Roboto", Sans-serif;
        font-size: 140px;
        font-weight: 900;
        line-height: 130px;
    }
</style>
<main id="main" class="site-main clr"  role="main">

    <div data-elementor-type="wp-page" data-elementor-id="2124" class="elementor elementor-2124">
                <section class="elementor-section elementor-top-section elementor-element elementor-element-18a8cf87 elementor-section-full_width elementor-section-height-full elementor-section-height-default elementor-section-items-middle" data-id="18a8cf87" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
    <div class="elementor-container elementor-column-gap-extended">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a94cfad" data-id="2a94cfad" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-1be14109 elementor-widget elementor-widget-elementskit-heading" data-id="1be14109" data-element_type="widget" data-widget_type="elementskit-heading.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" ><div class="ekit-heading elementskit-section-title-wraper text_center   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="ekit-heading--title elementskit-section-title ">Coming Soon</h2></div></div>		</div>
</div>
</div>
</div>
        </div>
</section>
    </div>

</main><!-- #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\hostLaravel\resources\views/speakers.blade.php ENDPATH**/ ?>