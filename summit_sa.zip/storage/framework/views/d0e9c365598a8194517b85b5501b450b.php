<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Clients register</div>

                <div class="card-body">
                    <table class="table table-bordered table-responsive">
                        <thead>
                          <tr class="table-dark">
                            <th scope="col">Name</th>
                            <th scope="col">Job Title</th>
                            <th scope="col">Company Name</th>
                            <th scope="col">Mobile</th>
                            <th scope="col">Email</th>
                            <th scope="col">Industry</th>
                            <th scope="col">Interested</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if(count($clients) > 0): ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></th>
                                        <td><?php echo e($client->job_title); ?></td>
                                        <td><?php echo e($client->company_name); ?></td>
                                        <td><?php echo e($client->mobile); ?></td>
                                        <td><?php echo e($client->email); ?></td>
                                        <td><?php echo e($client->industry); ?></td>
                                        <td><?php echo e($client->interested); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr class="table-secondary">
                                <th class="text-center p-4" colspan="7">Table is EMPTY</th>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                      </table>

                      <?php if(count($clients) > 0): ?>
                      <?php echo e($clients->links()); ?>

                      <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('c-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\hostLaravel\resources\views/home.blade.php ENDPATH**/ ?>