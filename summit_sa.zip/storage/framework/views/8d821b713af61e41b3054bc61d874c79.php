<body
class="home page-template-default page page-id-674 wp-embed-responsive ehf-header ehf-footer ehf-template-oceanwp ehf-stylesheet-oceanwp qodef-qi--no-touch qi-addons-for-elementor-1.5.7 oceanwp-theme dropdown-mobile default-breakpoint content-full-screen has-topbar page-header-disabled no-margins elementor-default elementor-kit-23 elementor-page elementor-page-674"
itemscope="itemscope" itemtype="https://schema.org/WebPage">

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-dark-grayscale">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0 0.49803921568627" />
                <feFuncG type="table" tableValues="0 0.49803921568627" />
                <feFuncB type="table" tableValues="0 0.49803921568627" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-grayscale">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0 1" />
                <feFuncG type="table" tableValues="0 1" />
                <feFuncB type="table" tableValues="0 1" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-purple-yellow">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" />
                <feFuncG type="table" tableValues="0 1" />
                <feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-blue-red">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0 1" />
                <feFuncG type="table" tableValues="0 0.27843137254902" />
                <feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-midnight">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0 0" />
                <feFuncG type="table" tableValues="0 0.64705882352941" />
                <feFuncB type="table" tableValues="0 1" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-magenta-yellow">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0.78039215686275 1" />
                <feFuncG type="table" tableValues="0 0.94901960784314" />
                <feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-purple-green">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" />
                <feFuncG type="table" tableValues="0 1" />
                <feFuncB type="table" tableValues="0.44705882352941 0.4" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
        <filter id="wp-duotone-blue-orange">
            <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
                values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
            <feComponentTransfer color-interpolation-filters="sRGB">
                <feFuncR type="table" tableValues="0.098039215686275 1" />
                <feFuncG type="table" tableValues="0 0.66274509803922" />
                <feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" />
                <feFuncA type="table" tableValues="1 1" />
            </feComponentTransfer>
            <feComposite in2="SourceGraphic" operator="in" />
        </filter>
    </defs>
</svg>

<div id="outer-wrap" class="site clr">

    <a class="skip-link screen-reader-text" href="<?php echo e(route('home')); ?>#main">Skip to content</a>


    <div id="wrap" class="clr">


        <header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
            <p class="main-title bhf-hidden" itemprop="headline"><a href="index.html"
                    title="Saudi Construction Excellence Summit 2023" rel="home">Saudi Construction Excellence
                    Summit 2023</a></p>
            <div data-elementor-type="wp-post" data-elementor-id="10" class="elementor elementor-10">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-c38ed11 elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="c38ed11" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c2f2647"
                            data-id="c2f2647" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-63dd655 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="63dd655" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-691eb00"
                                            data-id="691eb00" data-element_type="column">
                                            <div class="elementor-widget-wrap">
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7b4e3e2"
                                            data-id="7b4e3e2" data-element_type="column">
                                            <div class="elementor-widget-wrap">
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4693404"
                                            data-id="4693404" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-246effc elementor-widget elementor-widget-heading"
                                                    data-id="246effc" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <style>
                                                            /*! elementor - v3.11.3 - 07-03-2023 */
                                                            .elementor-heading-title {
                                                                padding: 0;
                                                                margin: 0;
                                                                line-height: 1
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a {
                                                                color: inherit;
                                                                font-size: inherit;
                                                                line-height: inherit
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                                                                font-size: 15px
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                                                                font-size: 19px
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                                                                font-size: 29px
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                                                                font-size: 39px
                                                            }

                                                            .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                                                                font-size: 59px
                                                            }
                                                        </style>
                                                        <h6 class="elementor-heading-title elementor-size-default">
                                                            FOLLOW US</h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-51f10c1"
                                            data-id="51f10c1" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-9c50cc6 elementor-widget elementor-widget-elementskit-social-media"
                                                    data-id="9c50cc6" data-element_type="widget"
                                                    data-widget_type="elementskit-social-media.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="ekit-wid-con">
                                                            <ul class="ekit_social_media">
                                                                <li class="elementor-repeater-item-879cea4">
                                                                    <a href="javascript:void(0)"
                                                                        target="_blank" aria-label="LinkedIn"
                                                                        class="linkedin">

                                                                        <i aria-hidden="true"
                                                                            class="icon icon-linkedin"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="elementor-repeater-item-2a9413d">
                                                                    <a href="javascript:void(0)" target="_blank"
                                                                        aria-label="Twitter" class="twitter">

                                                                        <i aria-hidden="true"
                                                                            class="icon icon-twitter"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="elementor-repeater-item-89b9345">
                                                                    <a href="javascript:void(0)"
                                                                        target="_blank" aria-label="Facebook"
                                                                        class="facebook">

                                                                        <i aria-hidden="true"
                                                                            class="icon icon-facebook"></i>
                                                                    </a>
                                                                </li>
                                                                <li class="elementor-repeater-item-c4fb78a">
                                                                    <a href="javascript:void(0)"
                                                                        target="_blank" aria-label="instagram"
                                                                        class="1">

                                                                        <i aria-hidden="true"
                                                                            class="icon icon-instagram-1"></i>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-c4221ad elementor-hidden-tablet elementor-hidden-mobile elementor-hidden-desktop elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="c4221ad" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8a20af4"
                            data-id="8a20af4" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-2bcdb91 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="2bcdb91" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-no">
                                        <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-6b63d8e"
                                            data-id="6b63d8e" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-df59f4c elementor-widget elementor-widget-image"
                                                    data-id="df59f4c" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <style>
                                                            /*! elementor - v3.11.3 - 07-03-2023 */
                                                            .elementor-widget-image {
                                                                text-align: center
                                                            }

                                                            .elementor-widget-image a {
                                                                display: inline-block
                                                            }

                                                            .elementor-widget-image a img[src$=".svg"] {
                                                                width: 48px
                                                            }

                                                            .elementor-widget-image img {
                                                                vertical-align: middle;
                                                                display: inline-block
                                                            }
                                                        </style> <img width="300" height="154"
                                                            src="<?php echo e(asset("wp-content/uploads/2023/01/logo-5-300x154.png")); ?>"
                                                            class="attachment-medium size-medium wp-image-27" alt=""
                                                            loading="lazy"
                                                            srcset="<?php echo e(asset("wp-content/uploads/2023/01/logo-5-300x154.png")); ?> 300w, <?php echo e(asset("wp-content/uploads/2023/01/logo-5.png")); ?> 500w"
                                                            sizes="(max-width: 300px) 100vw, 300px" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-5166b7a"
                                            data-id="5166b7a" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-fcda460 elementor-widget elementor-widget-heading"
                                                    data-id="fcda460" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">
                                                            04 - 05 JUNE 2023</h2>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-700b2e2 elementor-widget elementor-widget-heading"
                                                    data-id="700b2e2" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h3 class="elementor-heading-title elementor-size-default">
                                                            Ritz-Carlton, Riyadh</h3>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-0ae6dba elementor-widget elementor-widget-heading"
                                                    data-id="0ae6dba" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h3 class="elementor-heading-title elementor-size-default">
                                                            Saudi Arabia</h3>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-60f84e6 elementor-widget elementor-widget-heading"
                                                    data-id="60f84e6" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h3 class="elementor-heading-title elementor-size-default">
                                                            #SCES2023</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-c584d12"
                                            data-id="c584d12" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-714e5cd elementor-widget elementor-widget-image"
                                                    data-id="714e5cd" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img width="300" height="300"
                                                            src="<?php echo e(asset("wp-content/uploads/2023/01/momra_logo-2.png")); ?>"
                                                            class="attachment-medium size-medium wp-image-134"
                                                            alt="" loading="lazy"
                                                            srcset="<?php echo e(asset("wp-content/uploads/2023/01/momra_logo-2.png")); ?> 300w, <?php echo e(asset("wp-content/uploads/2023/01/momra_logo-2-150x150.png")); ?> 150w"
                                                            sizes="(max-width: 300px) 100vw, 300px" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-eff4600"
                                            data-id="eff4600" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-7e6f51d elementor-widget elementor-widget-heading"
                                                    data-id="7e6f51d" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h3 class="elementor-heading-title elementor-size-default">
                                                            Under the Patronage of</h3>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-74c89dc elementor-widget elementor-widget-heading"
                                                    data-id="74c89dc" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">
                                                            H.E MAJED BIN ABDULLAH BIN HAMAD AL HOGAIL</h2>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-50f6b2b elementor-widget elementor-widget-heading"
                                                    data-id="50f6b2b" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h3 class="elementor-heading-title elementor-size-default">
                                                            Minister of Municipal & Rural Affairs & Housing</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-2c75d35"
                                            data-id="2c75d35" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-a633230 elementor-widget elementor-widget-image"
                                                    data-id="a633230" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img width="259" height="300"
                                                            src="<?php echo e(asset("wp-content/uploads/2023/01/minister-pic-1-259x300.jpg")); ?>"
                                                            class="attachment-medium size-medium wp-image-28" alt=""
                                                            loading="lazy"
                                                            srcset="<?php echo e(asset("wp-content/uploads/2023/01/minister-pic-1-259x300.jpg")); ?> 259w, <?php echo e(asset("wp-content/uploads/2023/01/minister-pic-1.jpg")); ?> 362w"
                                                            sizes="(max-width: 259px) 100vw, 259px" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-08733a2 she-header-yes elementor-hidden-tablet elementor-hidden-mobile elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                    data-id="08733a2" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;transparent&quot;:&quot;yes&quot;,&quot;scroll_distance&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:166,&quot;sizes&quot;:[]},&quot;transparent_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;scroll_distance_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;scroll_distance_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}">
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-041e223"
                            data-id="041e223" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-e15737f elementor-widget elementor-widget-image"
                                    data-id="e15737f" data-element_type="widget" data-widget_type="image.default">
                                    <div class="elementor-widget-container">
                                        <img width="500" height="256" src="<?php echo e(asset("wp-content/uploads/2023/01/logo-5.png")); ?>"
                                            class="attachment-large size-large wp-image-27" alt="" loading="lazy"
                                            srcset="<?php echo e(asset("wp-content/uploads/2023/01/logo-5.png")); ?> 500w, <?php echo e(asset("wp-content/uploads/2023/01/logo-5-300x154.png")); ?> 300w"
                                            sizes="(max-width: 500px) 100vw, 500px" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-e475eac"
                            data-id="e475eac" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-229c1e5 elementor-widget elementor-widget-heading"
                                    data-id="229c1e5" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">13 -14 NOV 2023
                                        </h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-3ebfb68 elementor-widget elementor-widget-heading"
                                    data-id="3ebfb68" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h3 class="elementor-heading-title elementor-size-default">Ritz-Carlton,
                                            Riyadh</h3>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-72d4571 elementor-widget elementor-widget-heading"
                                    data-id="72d4571" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h3 class="elementor-heading-title elementor-size-default">Saudi Arabia</h3>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-a4ea8df elementor-widget elementor-widget-heading"
                                    data-id="a4ea8df" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h3 class="elementor-heading-title elementor-size-default">#SCES2023</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-ac15f99"
                            data-id="ac15f99" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-26f745b hfe-nav-menu__align-left hfe-submenu-icon-arrow hfe-submenu-animation-none hfe-link-redirect-child hfe-nav-menu__breakpoint-tablet elementor-widget elementor-widget-navigation-menu"
                                    data-id="26f745b" data-element_type="widget"
                                    data-settings="{&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:3,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;width_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;220&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true}}"
                                    data-widget_type="navigation-menu.default">
                                    <div class="elementor-widget-container">
                                        <div class="hfe-nav-menu hfe-layout-horizontal hfe-nav-menu-layout horizontal hfe-pointer__underline hfe-animation__slide"
                                            data-layout="horizontal" data-last-item="cta">
                                            <div class="hfe-nav-menu__toggle elementor-clickable">
                                                <div class="hfe-nav-menu-icon">
                                                    <i aria-hidden="true" tabindex="0" class=" icon_menu"></i>
                                                </div>
                                            </div>
                                            <nav class="hfe-nav-menu__layout-horizontal hfe-nav-menu__submenu-arrow"
                                                data-toggle-icon="&lt;i aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot; icon_menu&quot;&gt;&lt;/i&gt;"
                                                data-close-icon="&lt;i aria-hidden=&quot;true&quot; tabindex=&quot;0&quot; class=&quot;fas fa-minus&quot;&gt;&lt;/i&gt;"
                                                data-full-width="yes">
                                                <ul id="menu-1-26f745b" class="hfe-nav-menu">
                                                    <li id="menu-item-679"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-674 current_page_item parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('home')); ?>" class="hfe-menu-item">HOME</a></li>
                                                    <li id="menu-item-1074"
                                                        class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children parent hfe-has-submenu hfe-creative-menu">
                                                        <div class="hfe-has-submenu-container"><a
                                                                href="<?php echo e(route('home')); ?>#overview"
                                                                class="hfe-menu-item">OVERVIEW<span
                                                                    class='hfe-menu-toggle sub-arrow hfe-menu-child-0'><i
                                                                        class='fa'></i></span></a></div>
                                                        <ul class="sub-menu">
                                                            <li id="menu-item-1075"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                <a href="<?php echo e(route('home')); ?>#whysaudi"
                                                                    class="hfe-sub-menu-item hfe-sub-menu-item-active">Why
                                                                    Saudi Arabia?</a></li>
                                                            <li id="menu-item-1076"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                <a href="<?php echo e(route('home')); ?>#whoattend"
                                                                    class="hfe-sub-menu-item hfe-sub-menu-item-active">Who
                                                                    Will Attend?</a></li>
                                                            <li id="menu-item-1077"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                <a href="<?php echo e(route('home')); ?>#venue"
                                                                    class="hfe-sub-menu-item hfe-sub-menu-item-active">Venue</a>
                                                            </li>
                                                            <li id="menu-item-1400"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                <a href="<?php echo e(route('home')); ?>#"
                                                                    class="hfe-sub-menu-item">Visa, Travel &#038;
                                                                    Hotel</a></li>
                                                            <li id="menu-item-1401"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children hfe-has-submenu hfe-creative-menu">
                                                                <div class="hfe-has-submenu-container"><a
                                                                        href="<?php echo e(route('home')); ?>#"
                                                                        class="hfe-sub-menu-item">Media Center<span
                                                                            class='hfe-menu-toggle sub-arrow hfe-menu-child-1'><i
                                                                                class='fa'></i></span></a></div>
                                                                <ul class="sub-menu">
                                                                    <li id="menu-item-1402"
                                                                        class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                        <a href="<?php echo e(route('home')); ?>#"
                                                                            class="hfe-sub-menu-item">Photo
                                                                            Gallary</a></li>
                                                                    <li id="menu-item-1403"
                                                                        class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                        <a href="<?php echo e(route('home')); ?>#"
                                                                            class="hfe-sub-menu-item">Video
                                                                            Gallary</a></li>
                                                                    <li id="menu-item-1404"
                                                                        class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                        <a href="<?php echo e(route('home')); ?>#"
                                                                            class="hfe-sub-menu-item">Press
                                                                            Release</a></li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li id="menu-item-1334"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('speakers')); ?>"
                                                            class="hfe-menu-item">SPEAKERS</a></li>
                                                    <li id="menu-item-1316"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('agenda')); ?>"
                                                            class="hfe-menu-item">AGENDA</a></li>
                                                    <li id="menu-item-1940"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('media_partners')); ?>"
                                                            class="hfe-menu-item">ASSOCIATION &#038; MEDIA
                                                            PARTNERS</a></li>
                                                    <li id="menu-item-560"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('sponsors')); ?>"
                                                            class="hfe-menu-item">SPONSORS</a></li>
                                                    <li id="menu-item-672"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('news')); ?>"
                                                            class="hfe-menu-item">NEWS</a></li>
                                                    <li id="menu-item-754"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                        <a href="<?php echo e(route('register')); ?>"
                                                            class="hfe-menu-item">REGISTER NOW</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-bc82949 elementor-hidden-desktop elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="bc82949" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-no">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1db4feb"
                            data-id="1db4feb" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-732d7c4 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                    data-id="732d7c4" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-no">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-829eee0"
                                            data-id="829eee0" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-7fd8ce5 elementor-widget elementor-widget-site-logo"
                                                    data-id="7fd8ce5" data-element_type="widget"
                                                    data-settings="{&quot;align&quot;:&quot;center&quot;,&quot;width&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;space&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;space_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;space_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;image_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;image_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;image_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;caption_padding&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;caption_padding_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;caption_padding_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;caption_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;caption_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;caption_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                                                    data-widget_type="site-logo.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="hfe-site-logo">
                                                            <a data-elementor-open-lightbox=""
                                                                class='elementor-clickable' href="index.html">
                                                                <div class="hfe-site-logo-set">
                                                                    <div class="hfe-site-logo-container">
                                                                        <img class="hfe-site-logo-img elementor-animation-"
                                                                            src="<?php echo e(asset("wp-content/uploads/2023/01/logo-5-300x154.png")); ?>"
                                                                            alt="logo" />
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-b04416c"
                                            data-id="b04416c" data-element_type="column">
                                            <div class="elementor-widget-wrap">
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-a69b6f7"
                                            data-id="a69b6f7" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-0419fa7 hfe-menu-item-space-between hfe-submenu-icon-arrow hfe-link-redirect-child elementor-widget elementor-widget-navigation-menu"
                                                    data-id="0419fa7" data-element_type="widget"
                                                    data-settings="{&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:14,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:18,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;hamburger_align&quot;:&quot;center&quot;,&quot;hamburger_menu_align&quot;:&quot;space-between&quot;,&quot;width_flyout_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:300,&quot;sizes&quot;:[]},&quot;width_flyout_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_flyout_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_flyout_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;padding_flyout_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_flyout_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_top_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_top_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_top_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;close_flyout_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;close_flyout_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;close_flyout_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true}}"
                                                    data-widget_type="navigation-menu.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="hfe-nav-menu__toggle elementor-clickable hfe-flyout-trigger"
                                                            tabindex="0">
                                                            <div class="hfe-nav-menu-icon">
                                                                <i aria-hidden="true" tabindex="0"
                                                                    class="icon icon-menu-6"></i>
                                                            </div>
                                                        </div>
                                                        <div class="hfe-flyout-wrapper" data-last-item="cta">
                                                            <div class="hfe-flyout-overlay elementor-clickable">
                                                            </div>
                                                            <div class="hfe-flyout-container">
                                                                <div id="hfe-flyout-content-id-0419fa7"
                                                                    class="hfe-side hfe-flyout-left hfe-flyout-open"
                                                                    data-layout="left" data-flyout-type="normal">
                                                                    <div class="hfe-flyout-content push">
                                                                        <nav>
                                                                            <ul id="menu-1-0419fa7"
                                                                                class="hfe-nav-menu">
                                                                                <li id="menu-item-679"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-674 current_page_item parent hfe-creative-menu">
                                                                                    <a href="index.html"
                                                                                        class="hfe-menu-item">HOME</a>
                                                                                </li>
                                                                                <li id="menu-item-1074"
                                                                                    class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children parent hfe-has-submenu hfe-creative-menu">
                                                                                    <div
                                                                                        class="hfe-has-submenu-container">
                                                                                        <a href="<?php echo e(route('home')); ?>#overview"
                                                                                            class="hfe-menu-item">OVERVIEW<span
                                                                                                class='hfe-menu-toggle sub-arrow hfe-menu-child-0'><i
                                                                                                    class='fa'></i></span></a>
                                                                                    </div>
                                                                                    <ul class="sub-menu">
                                                                                        <li id="menu-item-1075"
                                                                                            class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                                            <a href="<?php echo e(route('home')); ?>#whysaudi"
                                                                                                class="hfe-sub-menu-item hfe-sub-menu-item-active">Why
                                                                                                Saudi Arabia?</a>
                                                                                        </li>
                                                                                        <li id="menu-item-1076"
                                                                                            class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                                            <a href="<?php echo e(route('home')); ?>#whoattend"
                                                                                                class="hfe-sub-menu-item hfe-sub-menu-item-active">Who
                                                                                                Will Attend?</a>
                                                                                        </li>
                                                                                        <li id="menu-item-1077"
                                                                                            class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home hfe-creative-menu">
                                                                                            <a href="<?php echo e(route('home')); ?>#venue"
                                                                                                class="hfe-sub-menu-item hfe-sub-menu-item-active">Venue</a>
                                                                                        </li>
                                                                                        <li id="menu-item-1400"
                                                                                            class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                                            <a href="<?php echo e(route('home')); ?>#"
                                                                                                class="hfe-sub-menu-item">Visa,
                                                                                                Travel &#038;
                                                                                                Hotel</a></li>
                                                                                        <li id="menu-item-1401"
                                                                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children hfe-has-submenu hfe-creative-menu">
                                                                                            <div
                                                                                                class="hfe-has-submenu-container">
                                                                                                <a href="<?php echo e(route('home')); ?>#"
                                                                                                    class="hfe-sub-menu-item">Media
                                                                                                    Center<span
                                                                                                        class='hfe-menu-toggle sub-arrow hfe-menu-child-1'><i
                                                                                                            class='fa'></i></span></a>
                                                                                            </div>
                                                                                            <ul class="sub-menu">
                                                                                                <li id="menu-item-1402"
                                                                                                    class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                                                    <a href="<?php echo e(route('home')); ?>#"
                                                                                                        class="hfe-sub-menu-item">Photo
                                                                                                        Gallary</a>
                                                                                                </li>
                                                                                                <li id="menu-item-1403"
                                                                                                    class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                                                    <a href="<?php echo e(route('home')); ?>#"
                                                                                                        class="hfe-sub-menu-item">Video
                                                                                                        Gallary</a>
                                                                                                </li>
                                                                                                <li id="menu-item-1404"
                                                                                                    class="menu-item menu-item-type-custom menu-item-object-custom hfe-creative-menu">
                                                                                                    <a href="<?php echo e(route('home')); ?>#"
                                                                                                        class="hfe-sub-menu-item">Press
                                                                                                        Release</a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </li>
                                                                                    </ul>
                                                                                </li>
                                                                                <li id="menu-item-1334"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('speakers')); ?>"
                                                                                        class="hfe-menu-item">SPEAKERS</a>
                                                                                </li>
                                                                                <li id="menu-item-1316"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('agenda')); ?>"
                                                                                        class="hfe-menu-item">AGENDA</a>
                                                                                </li>
                                                                                <li id="menu-item-1940"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('media_partners')); ?>"
                                                                                        class="hfe-menu-item">ASSOCIATION
                                                                                        &#038; MEDIA PARTNERS</a>
                                                                                </li>
                                                                                <li id="menu-item-560"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('sponsors')); ?>"
                                                                                        class="hfe-menu-item">SPONSORS</a>
                                                                                </li>
                                                                                <li id="menu-item-672"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('news')); ?>"
                                                                                        class="hfe-menu-item">NEWS</a>
                                                                                </li>
                                                                                <li id="menu-item-754"
                                                                                    class="menu-item menu-item-type-post_type menu-item-object-page parent hfe-creative-menu">
                                                                                    <a href="<?php echo e(route('register')); ?>"
                                                                                        class="hfe-menu-item">REGISTER
                                                                                        NOW</a></li>
                                                                            </ul>
                                                                        </nav>
                                                                        <div class="elementor-clickable hfe-flyout-close"
                                                                            tabindex="0">
                                                                            <i aria-hidden="true" tabindex="0"
                                                                                class=" icon_close"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </header>
<?php /**PATH K:\hostLaravel\resources\views/layout/header.blade.php ENDPATH**/ ?>